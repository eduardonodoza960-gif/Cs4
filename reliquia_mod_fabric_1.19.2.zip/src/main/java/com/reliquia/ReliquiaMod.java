package com.reliquia;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class ReliquiaMod implements ModInitializer {

    private static void makeIndestructible(ItemStack stack, String tagKey) {
        NbtCompound nbt = stack.getOrCreateNbt();
        nbt.putBoolean("Unbreakable", true);
        nbt.putBoolean("ReliquiaItem", true);
        nbt.putBoolean(tagKey, true);
        stack.addHideFlag(ItemStack.TooltipSection.UNBREAKABLE);
    }

    public static boolean isReliquiaItem(ItemStack stack) {
        if (stack.isEmpty() || !stack.hasNbt()) return false;
        return stack.getNbt().getBoolean("ReliquiaItem");
    }

    public static ItemStack createEspadaDoCacador() {
        ItemStack sword = new ItemStack(Items.GOLDEN_SWORD);
        MutableText name = Text.literal("Espada do Caçador")
                .setStyle(Style.EMPTY.withColor(Formatting.YELLOW).withBold(true).withUnderline(true).withItalic(false));
        sword.setCustomName(name);
        makeIndestructible(sword, "ReliquiaEspadaCacador");
        return sword;
    }

    public static boolean isEspadaDoCacador(ItemStack stack) {
        if (stack.isEmpty() || !stack.isOf(Items.GOLDEN_SWORD)) return false;
        NbtCompound nbt = stack.getNbt();
        if (nbt != null && nbt.getBoolean("ReliquiaEspadaCacador")) return true;
        return stack.hasCustomName() && stack.getName().getString().equals("Espada do Caçador");
    }

    public static ItemStack createPenaLendaria() {
        ItemStack feather = new ItemStack(Items.FEATHER);
        MutableText name = Text.literal("Pena Lendária")
                .setStyle(Style.EMPTY.withColor(Formatting.YELLOW).withBold(true).withUnderline(true).withItalic(false));
        feather.setCustomName(name);
        feather.addEnchantment(Enchantments.UNBREAKING, 1);
        feather.addHideFlag(ItemStack.TooltipSection.ENCHANTMENTS);
        makeIndestructible(feather, "ReliquiaPenaLendaria");
        return feather;
    }

    public static boolean isPenaLendaria(ItemStack stack) {
        if (stack.isEmpty() || !stack.isOf(Items.FEATHER)) return false;
        NbtCompound nbt = stack.getNbt();
        if (nbt != null && nbt.getBoolean("ReliquiaPenaLendaria")) return true;
        return stack.hasCustomName() && stack.getName().getString().equals("Pena Lendária");
    }

    public static ItemStack createEscudoLendario() {
        ItemStack shield = new ItemStack(Items.SHIELD);
        MutableText name = Text.literal("Escudo Lendário")
                .setStyle(Style.EMPTY.withColor(Formatting.YELLOW).withBold(true).withUnderline(true).withItalic(false));
        shield.setCustomName(name);
        shield.addEnchantment(Enchantments.UNBREAKING, 1);
        shield.addHideFlag(ItemStack.TooltipSection.ENCHANTMENTS);
        makeIndestructible(shield, "ReliquiaEscudoLendario");
        return shield;
    }

    public static boolean isEscudoLendario(ItemStack stack) {
        if (stack.isEmpty() || !stack.isOf(Items.SHIELD)) return false;
        NbtCompound nbt = stack.getNbt();
        if (nbt != null && nbt.getBoolean("ReliquiaEscudoLendario")) return true;
        return stack.hasCustomName() && stack.getName().getString().equals("Escudo Lendário");
    }

    public static ItemStack createPocaoLendaria() {
        // O item no menu / inventário é uma SPLASH_POTION
        ItemStack potion = new ItemStack(Items.SPLASH_POTION);
        MutableText name = Text.literal("Poção Lendária")
                .setStyle(Style.EMPTY.withColor(Formatting.YELLOW).withBold(true).withUnderline(true).withItalic(false));
        potion.setCustomName(name);

        NbtCompound nbt = potion.getOrCreateNbt();
        nbt.putInt("CustomPotionColor", 16711935);
        
        // Esconde o texto "Sem efeitos" / lista de efeitos na tooltip (HideFlags: 32)
        potion.addHideFlag(ItemStack.TooltipSection.ADDITIONAL);

        makeIndestructible(potion, "ReliquiaPocaoLendaria");
        return potion;
    }

    public static boolean isPocaoLendaria(ItemStack stack) {
        if (stack.isEmpty() || !stack.isOf(Items.SPLASH_POTION)) return false;
        NbtCompound nbt = stack.getNbt();
        if (nbt != null && nbt.getBoolean("ReliquiaPocaoLendaria")) return true;
        return stack.hasCustomName() && stack.getName().getString().equals("Poção Lendária");
    }

    private static void dispararSonicBoom(ServerWorld world, ServerPlayerEntity player) {
        Vec3d startPos = player.getEyePos();
        Vec3d lookVec = player.getRotationVec(1.0F).normalize();

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 3.0F, 1.0F);
        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENTITY_WARDEN_TENDRIL_CLICKING, SoundCategory.PLAYERS, 2.0F, 0.5F);

        Set<UUID> hitEntities = new HashSet<>();
        double maxDistance = 16.0;

        for (double d = 0.5; d <= maxDistance; d += 0.3) {
            Vec3d pPos = startPos.add(lookVec.multiply(d));

            world.spawnParticles(ParticleTypes.SONIC_CHARGE, pPos.x, pPos.y, pPos.z, 1, 0.05, 0.05, 0.05, 0.0);
            world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, pPos.x, pPos.y, pPos.z, 2, 0.1, 0.1, 0.1, 0.02);

            Box hitBox = new Box(pPos.subtract(1.0, 1.0, 1.0), pPos.add(1.0, 1.0, 1.0));
            List<Entity> targets = world.getOtherEntities(player, hitBox, e -> e instanceof LivingEntity && e.isAlive());

            for (Entity target : targets) {
                if (hitEntities.add(target.getUuid())) {
                    target.damage(DamageSource.player(player), 3.5F);

                    double knockbackStrength = 10.0 * 0.45;
                    Vec3d push = new Vec3d(lookVec.x * knockbackStrength, 0.4, lookVec.z * knockbackStrength);
                    target.setVelocity(push);
                    target.velocityModified = true;
                }
            }
        }
    }

    @Override
    public void onInitialize() {
        // Registra o comando /cs4
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("cs4")
                .executes(context -> {
                    ServerPlayerEntity player = context.getSource().getPlayer();
                    if (player != null) {
                        MutableText menuTitle = Text.literal("CS").formatted(Formatting.GOLD, Formatting.BOLD)
                                .append(Text.literal("» ").formatted(Formatting.GRAY))
                                .append(Text.literal("Relíquia").formatted(Formatting.GRAY));

                        player.openHandledScreen(new NamedScreenHandlerFactory() {
                            @Override
                            public Text getDisplayName() {
                                return menuTitle;
                            }

                            @Override
                            public ScreenHandler createMenu(int syncId, PlayerInventory inv, PlayerEntity p) {
                                SimpleInventory menuInv = new SimpleInventory(18);
                                menuInv.setStack(0, createEspadaDoCacador());
                                menuInv.setStack(1, createPenaLendaria());
                                menuInv.setStack(2, createEscudoLendario());
                                menuInv.setStack(3, createPocaoLendaria());

                                return new GenericContainerScreenHandler(ScreenHandlerType.GENERIC_9X2, syncId, inv, menuInv, 2) {
                                    @Override
                                    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity playerEntity) {
                                        if (slotIndex >= 0 && slotIndex < 18) {
                                            ItemStack clicked = this.getInventory().getStack(slotIndex);
                                            if (!clicked.isEmpty()) {
                                                playerEntity.getInventory().offerOrDrop(clicked.copy());
                                            }
                                            return;
                                        }
                                        super.onSlotClick(slotIndex, button, actionType, playerEntity);
                                    }
                                };
                            }
                        });
                    }
                    return 1;
                })
            );
        });

        // Eventos de clique / uso de itens
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            
            // 1. Escudo Lendário (Sonic Boom com recarga de 10 segundos = 200 ticks)
            if (isEscudoLendario(stack)) {
                if (!world.isClient && player instanceof ServerPlayerEntity serverPlayer) {
                    if (!serverPlayer.getItemCooldownManager().isCoolingDown(stack.getItem())) {
                        dispararSonicBoom((ServerWorld) world, serverPlayer);
                        serverPlayer.getItemCooldownManager().set(stack.getItem(), 200);
                    }
                }
                return TypedActionResult.success(stack, world.isClient());
            }

            // 2. Poção Lendária (O item na mão é SPLASH_POTION, mas o projétil arremessado é LINGERING_POTION com cor 16711935)
            if (isPocaoLendaria(stack)) {
                if (!world.isClient && player instanceof ServerPlayerEntity serverPlayer) {
                    if (!serverPlayer.getAbilities().creativeMode) {
                        stack.decrement(1);
                    }

                    world.playSound(null, player.getX(), player.getY(), player.getZ(),
                            SoundEvents.ENTITY_LINGERING_POTION_THROW, SoundCategory.PLAYERS, 0.5F, 0.4F / (world.getRandom().nextFloat() * 0.4F + 0.8F));

                    // Cria o projétil PotionEntity com o item LINGERING_POTION (cor 16711935) para voar e estourar como lingering potion!
                    PotionEntity potionEntity = new PotionEntity(world, serverPlayer);
                    ItemStack projectileItem = new ItemStack(Items.LINGERING_POTION);
                    NbtCompound projNbt = projectileItem.getOrCreateNbt();
                    projNbt.putInt("CustomPotionColor", 16711935);
                    projNbt.putBoolean("ReliquiaLingeringCloud", true);
                    
                    potionEntity.setItem(projectileItem);
                    potionEntity.setVelocity(player, player.getPitch(), player.getYaw(), -20.0f, 0.5f, 1.0f);
                    world.spawnEntity(potionEntity);
                }
                return TypedActionResult.success(stack, world.isClient());
            }

            return TypedActionResult.pass(stack);
        });

        // Loop imperativo e verificação de nuvens persistentes criadas pela Poção Lendária
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            long ticks = server.getOverworld().getTime();
            
            if (ticks % 20 == 0) {
                for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                    ItemStack mainHand = player.getMainHandStack();
                    ItemStack offHand = player.getOffHandStack();

                    if (isEspadaDoCacador(mainHand) || isEspadaDoCacador(offHand)) {
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.BAD_OMEN, 20, 5, false, false, true));
                    }

                    if (isPenaLendaria(mainHand) || isPenaLendaria(offHand)) {
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 80, 12, false, false, true));
                    }
                }
            }

            // Aplica Cegueira por 10 segundos (200 ticks) apenas nas nuvens com a cor da Poção Lendária (16711935)
            for (ServerWorld world : server.getWorlds()) {
                for (Entity entity : world.iterateEntities()) {
                    if (entity instanceof AreaEffectCloudEntity cloud && cloud.getColor() == 16711935) {
                        Box box = cloud.getBoundingBox();
                        List<LivingEntity> targets = world.getEntitiesByClass(LivingEntity.class, box, e -> e.isAlive());
                        for (LivingEntity target : targets) {
                            target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 200, 0, false, false, true));
                        }
                    }
                }
            }
        });
    }
}
