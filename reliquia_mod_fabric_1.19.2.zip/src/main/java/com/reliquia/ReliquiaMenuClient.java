package com.reliquia;

import net.fabricmc.api.ClientModInitializer;

public class ReliquiaMenuClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
    }
}
